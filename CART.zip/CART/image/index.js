// For Plus
function increment(inDec,pcr,itm){
    var count= document.getElementById(inDec);
    var price= document.getElementById(pcr);
    var item= document.getElementById(itm);
    var pr_amount=document.getElementById('pr_amount').innerHTML;
    var charge =document.getElementById('charge').innerHTML;
    var total_amount=document.getElementById('total_amount').innerHTML;
    if(count.value>=5){
        count.value=5;
        alert('only 5 Product Allowed !');
    }else{
        count.value++;
        var result=parseInt(price.innerHTML)+parseInt(item.innerHTML);
        item.innerHTML=result;
        //for product amount
        var total_product=parseInt(price.innerHTML)+parseInt(pr_amount);
        document.getElementById('pr_amount').innerHTML= total_product;
        //total_product+Charge
        var newresult=total_product+parseInt(charge);
        document.getElementById('total_amount').innerHTML=newresult;
        var coupon_main_div=document.getElementById('coupon_main_div');
        
        if(total_product>= 300){
            coupon_main_div.style.display="block"; 
        }
       

    }
}
//for minus
function decrement(inDec,pcr,itm){
    var count = document.getElementById(inDec);
    var price= document.getElementById(pcr);
    var item= document.getElementById(itm);
    var pr_amount=document.getElementById('pr_amount').innerHTML;
    var charge =document.getElementById('charge').innerHTML;
    var total_amount=document.getElementById('total_amount').innerHTML;
    if(count.value<=0){
        count.value=0;
        alert('only minimum 1 Product Allowed !');
    }else{
        count.value--;
        var result=parseInt(item.innerHTML)-parseInt(price.innerHTML);
        item.innerHTML=result;
        //for product amount
        var total_product=parseInt(pr_amount)-parseInt(price.innerHTML);
        document.getElementById('pr_amount').innerHTML= total_product;
         //total_product+Charge
         var newresult=total_product+parseInt(charge);
         document.getElementById('total_amount').innerHTML=newresult;    
       
        
    }
}
var coupon_main_div=document.getElementById('coupon_main_div');
coupon_main_div.style.display="none";
var applyBtn=document.getElementById('applyBtn');
applyBtn.addEventListener('click',function(){
    var coupon_input=document.getElementById('coupon_input');
    var total_amount=document.getElementById('total_amount').innerHTML;
    if(coupon_input.value=='KAZI_AFTAB'){
    var total=parseInt(total_amount)-50;
    document.getElementById('total_amount').innerHTML=total;
    alert('Congratulations.');
    coupon_main_div.style.display="none";
    }else{
        alert('Coupon not Match !!');
    }

});